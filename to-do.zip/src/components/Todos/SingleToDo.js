import React, { useState, useEffect } from 'react'
import axios from 'axios'

export const SingleToDo = ({ toDo }) => {
  const [categories, setCategories] = useState([]);

  const getCategories = () => {
    axios.get(`https://localhost:7043/api/Categories`).then(res => {
      setCategories(res.data)
    })
  }

  useEffect(() => {
    getCategories()
  }, []);

  return (
    <tr>
      <td>{toDo.name}</td>
      <td className='text-capitalize'>{categories.map(x => 
        x.categoryId === toDo.categoryId && x.catName 
        )}</td>
        <td className='controls'>
          <button className="btn btn-warning mx-5">Edit</button>
          <button className="btn btn-danger">Delete</button>
        </td>
    </tr>
  )
}
