import React from 'react'

export const Categories = () => {
  return (
    <h1>Categories</h1>
  )
}
