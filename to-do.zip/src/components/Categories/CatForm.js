import React from 'react'

export const CatForm = () => {
  return (
    <div>CatForm</div>
  )
}
